class Day3{
   public static void main(String args[]){
    for(int i=11;i<20;i++){
             System.out.println(i);
       }
}
}